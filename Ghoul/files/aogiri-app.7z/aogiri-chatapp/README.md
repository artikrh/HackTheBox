# Aogiri chat application

Replaces the old php application because it sucked. Uses spring and hibernate as well as others.
