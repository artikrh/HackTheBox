package com.aogiri.aogirichatapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AogiriChatappApplication {

	public static void main(String[] args) {
		SpringApplication.run(AogiriChatappApplication.class, args);
	}

}

